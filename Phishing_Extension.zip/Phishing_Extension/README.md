# 🛡️ PhishGuard — AI-Based Phishing Email Detection

A browser extension + ML backend that detects phishing emails in **Gmail** and **Outlook** in real time.

---

## 📁 Project Structure

```
phishguard/
├── extension/               # Chrome/Edge browser extension
│   ├── manifest.json        # Extension config (MV3)
│   ├── popup.html           # Extension popup UI
│   ├── popup.js             # Popup controller
│   ├── content.js           # Gmail/Outlook injector + extractor
│   ├── background.js        # Service worker
│   └── icons/               # Extension icons (add 16, 48, 128 px PNGs)
│
└── backend/                 # Python Flask ML API
    ├── train_model.py       # Train & save the ML model
    ├── app.py               # Flask REST API
    └── requirements.txt     # Python dependencies
```

---

## 🚀 Quick Start

### 1. Backend Setup

```bash
cd backend
pip install -r requirements.txt

# Train the ML model (creates phishguard_model.pkl)
python train_model.py

# Start the API server
python app.py
# → Running at http://localhost:5000
```

**Test the API:**
```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"subject": "URGENT: Verify your account!", "body": "Click here to avoid suspension http://secure-verify.tk"}'
```

Expected response:
```json
{
  "prediction": "phishing",
  "confidence": 0.9341,
  "factors": [
    { "icon": "🔗", "label": "Contains 1 URL(s)", "value": "MED", "severity": "medium" },
    { "icon": "⚠️", "label": "Suspicious domain extension (.tk...)", "value": "HIGH", "severity": "high" },
    { "icon": "⏰", "label": "Creates urgency or time pressure", "value": "MED", "severity": "medium" }
  ]
}
```

---

### 2. Load the Browser Extension

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `extension/` folder
5. The PhishGuard icon appears in your toolbar ✅

> **Icons:** Add `icon16.png`, `icon48.png`, `icon128.png` to `extension/icons/`. You can use any shield/security icon.

---

## 🧠 How the ML Model Works

### Algorithm: Naive Bayes (TF-IDF pipeline)

```
Email Text
    ↓
TF-IDF Vectorizer (1-2 grams, 5000 features, sublinear TF)
    ↓
Multinomial Naive Bayes (alpha=0.1)
    ↓
Prediction: phishing | safe   +   Confidence score
```

### Why Naive Bayes?
- Fast training & inference (< 1ms per prediction)
- Excellent for text classification with small datasets
- Interpretable probabilities
- Works well with TF-IDF features

### Feature Engineering (risk factors)
On top of the ML prediction, the API extracts human-readable risk signals:

| Feature | Description | Risk Level |
|---------|-------------|------------|
| URL count | Number of links in email | HIGH if > 2 |
| Suspicious TLD | `.tk`, `.ml`, `.xyz`, `.gq` etc. | HIGH |
| Keyword count | Urgent, verify, password, etc. | HIGH/MED/LOW |
| Urgency language | "Immediately", "24 hours" | MED |
| ALL CAPS subject | Subject in full uppercase | LOW |
| IP in URL | Raw IP address in link | HIGH |
| Special chars | Excessive `!`, `$`, `@` | LOW |

---

## 🔌 API Reference

### `POST /predict`

**Body:**
```json
{
  "subject": "Email subject line",
  "body": "Full email body text"
}
```

**Response:**
```json
{
  "prediction": "phishing",
  "confidence": 0.9341,
  "factors": [ ... ],
  "email_length": 342,
  "scanned_at": "2024-11-15T14:32:10"
}
```

### `GET /health`
Returns API status and model load state.

### `GET /stats`
Returns total scans, phishing count, safe count for this session.

---

## 🔧 Extension Architecture

```
Gmail/Outlook Page
       ↓
content.js (MutationObserver watches for email opens)
       ↓ extracts subject + body
background.js (service worker / message relay)
       ↓
Flask API @ localhost:5000/predict
       ↓
ML Prediction + Risk Factors
       ↓
popup.js (renders result card)
       +
content.js (injects red warning banner on page if phishing)
```

---

## 🚀 Upgrading the Model

### Use a Real Dataset
Download the [Enron Spam Dataset](https://www.kaggle.com/datasets/rtatman/fraudulent-email-corpus) or [CEAS-08](http://www.ceas.cc/2008/) for much better accuracy.

```python
import pandas as pd
df = pd.read_csv("emails.csv")  # columns: text, label
texts  = df["text"].tolist()
labels = df["label"].tolist()   # 0 = safe, 1 = phishing
```

### Try Logistic Regression
In `train_model.py`, swap:
```python
from sklearn.linear_model import LogisticRegression
("clf", LogisticRegression(C=1.0, max_iter=1000))
```

### Production: Use a Transformer Model
For maximum accuracy, use a fine-tuned BERT model via Hugging Face:
```bash
pip install transformers torch
```
Point the API at the model and update `app.py` accordingly.

---

## ⚙️ Configuration

### Change API Port
In `app.py`: `app.run(port=YOUR_PORT)`  
In `content.js` and `popup.js`: update `API_BASE`  
In `manifest.json`: update `host_permissions`

### Disable Auto-Scan
Toggle off in the extension popup, or set in storage:
```js
chrome.storage.local.set({ autoScan: false })
```

---

## 🛡️ Privacy & Security

- **All processing is local** — email content never leaves your machine
- The backend runs at `localhost:5000` only
- No data is stored or logged permanently
- Extension only reads email content when an email is open

---

## 📝 License

MIT License — free for personal and educational use.
